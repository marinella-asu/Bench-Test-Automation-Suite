import ctypes as ct
def cf( a_float ):
    return ct.c_double( a_float )
