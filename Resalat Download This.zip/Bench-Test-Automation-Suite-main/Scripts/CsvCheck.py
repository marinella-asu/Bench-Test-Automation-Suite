import pandas as pd
df = pd.read_csv('/home/evan/Bench_Test_Automation_Suite/Data/Evan/7_Die1_Device67_2025-02-14_12-10-00.csv', comment = '#')
print(df)
