def TestAddress(self):
    print(self.GetAddress())